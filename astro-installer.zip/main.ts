import { Installer } from './installer/install';

/**
 * Create the installer instance
 */

new Installer();