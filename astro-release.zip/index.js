/**
 * No builds created. Run `npm run build` to create a JS-supported build.
 */

console.log('Start failed because you haven\'t compiled your project yet.');
console.log('Did you mean:');
console.log('\nnpm run start:dev');
console.log()