export var Instance = {
    app: undefined
};