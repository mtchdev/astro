export const AppConfig = {
    name: 'Astro',
    port: 3000 // the server port
};