export const AppConfig = {
    name: 'Astro',
    port: 3000, // the server port
    routes: {
        api_prefix: 'api' // the API routes prefix. Do not include any / characters
    }
};