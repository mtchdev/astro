export const RouterConfig = {
    api_prefix: 'api', // The route prefix. For example: www.example.com/api/users (do not include /)
    allowed_ips: [] // If not empty, the router will only allow specific IP addresses to make requests.
}