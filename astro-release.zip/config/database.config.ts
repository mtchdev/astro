export const DBConfig = {
    mysql: {
        host: 'localhost',
        port: 8889,
        user: 'root',
        password: 'root',
        database: 'astro'
    }
}